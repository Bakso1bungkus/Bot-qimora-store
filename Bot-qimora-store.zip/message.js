module.exports = {
  menu: `
🌟 *Qimora Bot Menu* 🌟

1. !menu - Tampilkan menu
2. !ping - Cek bot aktif
3. !owner - Info pemilik
`
}